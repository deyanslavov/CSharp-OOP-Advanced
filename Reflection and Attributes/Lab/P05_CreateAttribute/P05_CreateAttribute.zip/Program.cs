﻿using System;

namespace P05_CreateAttribute
{
    [SoftUni("Beb4o")]
    class Program
    {
        [SoftUni("Dido")]
        static void Main()
        {
            
        }
    }
}
