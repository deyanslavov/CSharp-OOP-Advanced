﻿using System;

namespace P03_MissionPrivateImpossible
{
    class Program
    {
        static void Main(string[] args)
        {
            var spy = new Spy();

            Console.WriteLine(spy.RevealPrivateMethods("Hacker"));
        }
    }
}
