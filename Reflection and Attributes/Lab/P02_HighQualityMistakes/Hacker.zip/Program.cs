﻿using System;

namespace P02_HighQualityMistakes
{
    class Program
    {
        static void Main(string[] args)
        {
            var spy = new Spy();
            Console.WriteLine(spy.AnalyzeAcessModifiers("Hacker"));
        }
    }
}
