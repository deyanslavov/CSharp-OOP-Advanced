﻿using System;

namespace P04_Collector
{
    class Program
    {
        static void Main(string[] args)
        {
            var spy = new Spy();

            Console.WriteLine(spy.CollectGettersAndSetters("Hacker"));
        }
    }
}
