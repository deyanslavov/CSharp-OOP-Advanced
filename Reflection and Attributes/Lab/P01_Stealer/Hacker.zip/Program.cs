﻿using System;

namespace P01_Stealer
{
    class Program
    {
        static void Main(string[] args)
        {
            var spy = new Spy();

            Console.WriteLine(spy.StealFieldInfo("Hacker", "username", "password"));
        }
    }
}
