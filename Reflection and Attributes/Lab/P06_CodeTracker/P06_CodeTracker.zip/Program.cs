﻿using System;

namespace P06_CodeTracker
{
    class Program
    {
        [SoftUni("Beb4o")]
        public static void Main()
        {
            Tracker.PrintMethodsByAuthor();
        }
    }
}
